from django.db import models
from django.utils import timezone
#Extends user

#Models are tables that will be stored in a database
#https://simpleisbetterthancomplex.com/tutorial/2016/07/22/how-to-extend-django-user-model.html#proxy

class Location(models.Model):
    name = models.CharField(max_length = 60)

class Item(models.Model):
    name = models.CharField(max_length = 60)
    img = models.ImageField(upload_to='item_img', null = True)
    quantity = models.PositiveIntegerField(null = True, default=0)
    comment = models.TextField()
    category = models.CharField(max_length = 60)
    location = models.ForeignKey(Location, on_delete=models.CASCADE)
    
    def __str__(self):
        return self.name
    
